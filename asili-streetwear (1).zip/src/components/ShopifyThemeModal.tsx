import React, { useState } from 'react';
import { X, Copy, Check, Download, Folder, FileCode, ExternalLink, Sparkles, Code2, Layers } from 'lucide-react';
import JSZip from 'jszip';
import { SHOPIFY_THEME_FILES, ShopifyThemeFile } from '../data/shopifyThemeFiles';

interface ShopifyThemeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShopifyThemeModal: React.FC<ShopifyThemeModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<ShopifyThemeFile>(SHOPIFY_THEME_FILES[0]);
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  if (!isOpen) return null;

  const handleCopyCode = (file: ShopifyThemeFile) => {
    navigator.clipboard.writeText(file.code);
    setCopiedPath(file.path);
    setTimeout(() => setCopiedPath(null), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Add all liquid files to zip
      SHOPIFY_THEME_FILES.forEach(file => {
        zip.file(file.path, file.code);
      });

      // Add README.md
      zip.file("README.md", `# Asili.eg - Clean Minimalism Shopify Liquid Theme

## Installation Instructions

1. Log in to your Shopify Admin panel.
2. Go to **Online Store** > **Themes**.
3. Under the **Theme library** section, click **Add theme** > **Upload zip file**.
4. Upload this \`asili-clean-minimalism-shopify-theme.zip\` file.
5. Click **Actions** > **Publish** to make it your live store theme!

Designed with Clean Minimalism, 500GSM Egyptian Cotton aesthetic, and Arabic typography support.
`);

      const content = await zip.generateAsync({ type: 'blob' });
      const url = window.URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'asili-clean-minimalism-shopify-theme.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to generate zip", err);
    } finally {
      setIsZipping(false);
    }
  };

  const categories = Array.from(new Set(SHOPIFY_THEME_FILES.map(f => f.category)));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in select-text">
      <div className="bg-[#F9F9F9] border-2 border-black w-full max-w-6xl h-[90vh] flex flex-col shadow-2xl relative overflow-hidden">
        
        {/* MODAL HEADER */}
        <div className="bg-black text-white px-6 py-4 flex items-center justify-between border-b border-black">
          <div className="flex items-center gap-3">
            <Code2 className="w-5 h-5 text-white" />
            <div>
              <h2 className="text-sm font-black uppercase tracking-[0.2em]">
                SHOPIFY LIQUID THEME PACKAGE • CLEAN MINIMALISM
              </h2>
              <p className="text-[10px] text-white/60 tracking-widest uppercase">
                COMPLETE ONLINE STORE 2.0 THEME DIRECTORY READY FOR SHOPIFY ADMIN UPLOAD
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="group relative px-4 py-2 border border-white bg-white text-black text-[11px] font-black tracking-widest uppercase transition-all flex items-center gap-2"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isZipping ? 'PACKAGING ZIP...' : 'DOWNLOAD THEME (.ZIP)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-white/70 hover:text-white border border-white/20 hover:border-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* MODAL BODY GRID */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden bg-white">
          
          {/* FILE TREE SIDEBAR */}
          <div className="md:col-span-4 lg:col-span-3 border-r border-black/10 bg-[#F4F4F4] p-4 overflow-y-auto flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-40 mb-3 px-2">
                THEME STRUCTURE (LIQUID 2.0)
              </div>

              {categories.map(cat => (
                <div key={cat} className="mb-4">
                  <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black opacity-60 px-2 py-1 bg-black/5 rounded mb-1">
                    <Folder className="w-3 h-3" />
                    <span>{cat}/</span>
                  </div>

                  <div className="space-y-0.5">
                    {SHOPIFY_THEME_FILES.filter(f => f.category === cat).map(file => (
                      <button
                        key={file.path}
                        onClick={() => setSelectedFile(file)}
                        className={`w-full text-left px-3 py-2 text-xs font-mono flex items-center justify-between border transition-all ${selectedFile.path === file.path ? 'bg-black text-white font-bold border-black' : 'hover:bg-black/5 border-transparent text-black'}`}
                      >
                        <span className="truncate">{file.path.split('/')[1]}</span>
                        <FileCode className="w-3 h-3 opacity-50 flex-shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* QUICK STATS & INSTRUCTIONS */}
            <div className="mt-4 p-3 border border-black/10 bg-white text-[10px] font-mono space-y-2">
              <div className="font-bold uppercase tracking-wider text-black flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-black" />
                <span>Shopify OS 2.0 Ready</span>
              </div>
              <p className="text-black/70 leading-relaxed">
                Contains full theme files including Liquid templates, custom sections, schema options, and CSS.
              </p>
            </div>
          </div>

          {/* CODE PREVIEW PANEL */}
          <div className="md:col-span-8 lg:col-span-9 flex flex-col h-full bg-[#111111] text-gray-100 overflow-hidden">
            
            {/* FILE TOOLBAR */}
            <div className="bg-black border-b border-gray-800 px-6 py-3 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono font-bold text-white tracking-widest uppercase">
                  {selectedFile.path}
                </span>
                <p className="text-[10px] font-mono text-gray-400 mt-0.5">
                  {selectedFile.description}
                </p>
              </div>

              <button
                onClick={() => handleCopyCode(selectedFile)}
                className="px-3 py-1.5 border border-gray-700 hover:border-white bg-gray-900 text-xs font-mono uppercase tracking-wider text-white transition-all flex items-center gap-2"
              >
                {copiedPath === selectedFile.path ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-bold">COPIED!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>COPY LIQUID CODE</span>
                  </>
                )}
              </button>
            </div>

            {/* CODE EDITOR CONTENT */}
            <div className="flex-1 p-6 overflow-auto font-mono text-xs leading-relaxed text-emerald-400/90 selection:bg-white selection:text-black">
              <pre className="whitespace-pre-wrap font-mono text-gray-200">
                <code>{selectedFile.code}</code>
              </pre>
            </div>

            {/* BOTTOM BAR WITH IMPORT GUIDE */}
            <div className="bg-black/90 border-t border-gray-800 p-4 text-[11px] font-mono text-gray-400 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-white">
                <Layers className="w-4 h-4 text-white" />
                <span>HOW TO IMPORT IN SHOPIFY:</span>
                <span className="text-gray-400">Admin &gt; Online Store &gt; Themes &gt; Upload Zip File</span>
              </div>

              <button
                onClick={handleDownloadZip}
                disabled={isZipping}
                className="w-full sm:w-auto px-6 py-2 bg-white text-black font-bold uppercase tracking-widest hover:bg-gray-200 transition-colors"
              >
                {isZipping ? 'GENERATING ZIP...' : 'DOWNLOAD .ZIP FILE'}
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
