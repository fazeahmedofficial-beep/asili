import React, { useState } from 'react';
import { ShoppingBag, Search, Volume2, VolumeX, X, ArrowRight, Check, Plus, Minus, Code2, Download } from 'lucide-react';
import { ShopifyThemeModal } from './components/ShopifyThemeModal';

interface Product {
  id: string;
  name: string;
  arabicName: string;
  category: 'hoodies' | 'cargos' | 'tees' | 'jackets';
  priceEGP: number;
  priceUSD: number;
  image: string;
  imageDetail: string;
  gsm: string;
  fabric: string;
  badge: string;
  description: string;
}

const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'The Nefertiti Beyoncé Hoodie',
    arabicName: 'هودي نفرتيتي الفاخر',
    category: 'hoodies',
    priceEGP: 2800,
    priceUSD: 95,
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80',
    imageDetail: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
    gsm: '500 GSM',
    fabric: '100% Egyptian Heavyweight French Terry Cotton',
    badge: 'LIMITED DROP',
    description: 'Constructed from custom-milled 500GSM Egyptian French Terry. Features tonal black-on-black embroidery of Nefertiti with Beyoncé archival lettering on the oversized double-layered hood.'
  },
  {
    id: 'p2',
    name: 'Asili Multi-Way Cargos',
    arabicName: 'بنطال كارجو متعدد الاستخدامات',
    category: 'cargos',
    priceEGP: 2400,
    priceUSD: 80,
    image: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?auto=format&fit=crop&w=800&q=80',
    imageDetail: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80',
    gsm: '420 GSM',
    fabric: 'Egyptian Heavy Canvas Twill',
    badge: 'MODULAR DESIGN',
    description: 'Modular tactical cargos with 8 functional pockets, detachable strap harness, and adjustable ankle drawstrings. Custom laser-engraved hardware.'
  },
  {
    id: 'p3',
    name: 'Cairo Rosetta Oversized Tee',
    arabicName: 'تيشيرت حجر رشيد بالقاهرة',
    category: 'tees',
    priceEGP: 1400,
    priceUSD: 48,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
    imageDetail: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',
    gsm: '320 GSM',
    fabric: 'Combed Egyptian Cotton Jersey',
    badge: 'VINTAGE WASH',
    description: 'Heavyweight oversized tee with high-density screenprinted Rosetta Stone hieroglyphic graphic merged with modern Arabic typography.'
  },
  {
    id: 'p4',
    name: 'Kemet Monogram Varsity Jacket',
    arabicName: 'جاكيت فارستي كيميت أصيلي',
    category: 'jackets',
    priceEGP: 4200,
    priceUSD: 140,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=80',
    imageDetail: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80',
    gsm: '700 GSM',
    fabric: 'Melton Wool Body & Calfskin Leather Sleeves',
    badge: 'CRAFT EDITION',
    description: 'Hand-crafted varsity jacket featuring chenille "أصيلي" patchwork on chest, satin interior lining, and ancient Kemet crown embroidery.'
  },
  {
    id: 'p5',
    name: 'Luxor Ankh Heavyweight Zip',
    arabicName: 'هودي بسحاب مفتاح الحياة الأقصر',
    category: 'hoodies',
    priceEGP: 2600,
    priceUSD: 88,
    image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80',
    imageDetail: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80',
    gsm: '500 GSM',
    fabric: '100% Egyptian Heavyweight Cotton',
    badge: '3D PUFF PRINT',
    description: 'Dual-zipper boxy zip hoodie with 3D raised puff-printed Ankh emblem on chest and raw edge distress detailing.'
  },
  {
    id: 'p6',
    name: 'Pharaoh Boxy Acid Tee',
    arabicName: 'تيشيرت الفرعون أسيد واش',
    category: 'tees',
    priceEGP: 1500,
    priceUSD: 50,
    image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',
    imageDetail: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
    gsm: '320 GSM',
    fabric: 'Acid Washed Egyptian Cotton',
    badge: 'HAND DYED',
    description: 'Acid washed boxy fit tee with hand-stamped cultural heritage seal on reverse hem.'
  }
];

interface CartItem extends Product {
  size: string;
  qty: number;
}

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [currency, setCurrency] = useState<'EGP' | 'USD'>('EGP');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [selectedQuickView, setSelectedQuickView] = useState<Product | null>(null);
  const [quickViewSize, setQuickViewSize] = useState<string>('M');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [isShopifyModalOpen, setIsShopifyModalOpen] = useState(false);
  const [colorTheme, setColorTheme] = useState<'off-white' | 'dark-gray' | 'black'>('off-white');

  const themeStyles = {
    'off-white': {
      bg: 'bg-[#F9F9F9]',
      text: 'text-black',
      textMuted: 'text-black/70',
      textDim: 'text-black/40',
      border: 'border-black/10',
      borderBold: 'border-black',
      cardBg: 'bg-white',
      cardBgAlt: 'bg-[#F0F0F0]',
      headerBg: 'bg-[#F9F9F9]/95',
      btnPrimary: 'bg-black text-white hover:text-black border-black',
      btnOutline: 'bg-transparent text-black hover:text-white border-black',
      badgeBg: 'bg-black text-white',
      badgeBorder: 'bg-white text-black border-black',
      marqueeBg: 'bg-black text-white border-b border-black',
    },
    'dark-gray': {
      bg: 'bg-[#1A1A1A]',
      text: 'text-[#E5E5E5]',
      textMuted: 'text-white/70',
      textDim: 'text-white/40',
      border: 'border-white/15',
      borderBold: 'border-white',
      cardBg: 'bg-[#242424]',
      cardBgAlt: 'bg-[#2E2E2E]',
      headerBg: 'bg-[#1A1A1A]/95',
      btnPrimary: 'bg-white text-black hover:text-white border-white',
      btnOutline: 'bg-transparent text-white hover:text-black border-white',
      badgeBg: 'bg-white text-black',
      badgeBorder: 'bg-[#242424] text-white border-white',
      marqueeBg: 'bg-black text-white border-b border-white/20',
    },
    'black': {
      bg: 'bg-[#000000]',
      text: 'text-white',
      textMuted: 'text-white/70',
      textDim: 'text-white/40',
      border: 'border-white/20',
      borderBold: 'border-white',
      cardBg: 'bg-[#111111]',
      cardBgAlt: 'bg-[#1C1C1C]',
      headerBg: 'bg-[#000000]/95',
      btnPrimary: 'bg-white text-black hover:text-white border-white',
      btnOutline: 'bg-transparent text-white hover:text-black border-white',
      badgeBg: 'bg-white text-black',
      badgeBorder: 'bg-[#111111] text-white border-white',
      marqueeBg: 'bg-[#111111] text-white border-b border-white/20',
    }
  };

  const t = themeStyles[colorTheme];

  const playSound = () => {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.05);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch (e) {
      // Audio fallback
    }
  };

  const handleAddToCart = (product: Product, size: string = 'M') => {
    playSound();
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id && item.size === size);
      if (existing) {
        return prev.map(item => item.id === product.id && item.size === size ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { ...product, size, qty: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleRemoveFromCart = (id: string, size: string) => {
    playSound();
    setCart(prev => prev.filter(item => !(item.id === id && item.size === size)));
  };

  const handleQtyChange = (id: string, size: string, delta: number) => {
    playSound();
    setCart(prev => prev.map(item => {
      if (item.id === id && item.size === size) {
        const newQty = item.qty + delta;
        return newQty > 0 ? { ...item, qty: newQty } : item;
      }
      return item;
    }));
  };

  const filteredProducts = activeCategory === 'all'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === activeCategory);

  const searchFilteredProducts = searchQuery.trim() === ''
    ? []
    : PRODUCTS.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.arabicName.includes(searchQuery));

  const totalCartPrice = cart.reduce((sum, item) => {
    const price = currency === 'EGP' ? item.priceEGP : item.priceUSD;
    return sum + (price * item.qty);
  }, 0);

  const totalCartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const formatPrice = (egp: number, usd: number) => {
    return currency === 'EGP' ? `${egp.toLocaleString()} EGP` : `$${usd}`;
  };

  return (
    <div className={`${t.bg} ${t.text} font-sans min-h-screen flex flex-col relative select-none antialiased selection:bg-black selection:text-white transition-colors duration-300`}>
      
      {/* TOP MARQUEE TICKER */}
      <div className={`${t.marqueeBg} text-[10px] font-bold py-2.5 overflow-hidden relative z-50 uppercase tracking-[0.25em]`}>
        <div className="animate-marquee whitespace-nowrap flex gap-12 items-center">
          <span>REVIVING HISTORY ONE MORE TIME</span>
          <span>•</span>
          <span dir="rtl" className="font-medium">أصيلي • CAIRO, EGYPT</span>
          <span>•</span>
          <span>FREE EXPRESS SHIPPING ON ORDERS OVER 3000 EGP</span>
          <span>•</span>
          <span dir="rtl">صُنع في مصر 100% EGYPTIAN COTTON</span>
          <span>•</span>
          <span>ASILI.EG ARCHIVE DROP 004</span>
          <span>•</span>
          <span>REVIVING HISTORY ONE MORE TIME</span>
          <span>•</span>
          <span dir="rtl" className="font-medium">أصيلي • CAIRO, EGYPT</span>
          <span>•</span>
          <span>FREE EXPRESS SHIPPING ON ORDERS OVER 3000 EGP</span>
        </div>
      </div>

      {/* HEADER NAVIGATION */}
      <header className={`sticky top-0 z-40 ${t.headerBg} backdrop-blur-md ${t.border} border-b transition-all`}>
        <div className="max-w-7xl mx-auto px-6 sm:px-10 h-20 flex items-center justify-between">
          
          {/* BRAND LOGO */}
          <a href="#" className="flex items-baseline gap-4 group">
            <span className={`text-2xl font-black tracking-tighter uppercase ${t.text} group-hover:opacity-60 transition-opacity`}>
              Asili.eg
            </span>
            <span className={`text-xl font-medium tracking-widest ${t.textMuted}`} dir="rtl">
              أصيلي
            </span>
          </a>

          {/* DESKTOP NAV LINKS */}
          <nav className="hidden md:flex items-center gap-8 text-[11px] font-bold tracking-[0.2em] uppercase">
            <a href="#collection" onMouseEnter={playSound} className="hover:opacity-50 transition-opacity">
              Archive
            </a>
            <a href="#manifesto" onMouseEnter={playSound} className="hover:opacity-50 transition-opacity">
              Manifesto
            </a>
            <a href="#heritage" onMouseEnter={playSound} className="hover:opacity-50 transition-opacity">
              Heritage
            </a>
          </nav>

          {/* CONTROLS & COLOR SCHEME SWITCHER */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* COLOR THEME MODE TOGGLE */}
            <div className={`flex items-center border ${t.borderBold} p-0.5 text-[9px] font-black tracking-widest uppercase`}>
              <button 
                onClick={() => { setColorTheme('off-white'); playSound(); }}
                className={`px-2 py-1 transition-colors ${colorTheme === 'off-white' ? 'bg-black text-white' : 'hover:opacity-70'}`}
                title="Off-White Theme"
              >
                WHITE
              </button>
              <button 
                onClick={() => { setColorTheme('dark-gray'); playSound(); }}
                className={`px-2 py-1 transition-colors ${colorTheme === 'dark-gray' ? 'bg-black text-white' : 'hover:opacity-70'}`}
                title="Dark Gray Theme"
              >
                GRAY
              </button>
              <button 
                onClick={() => { setColorTheme('black'); playSound(); }}
                className={`px-2 py-1 transition-colors ${colorTheme === 'black' ? 'bg-white text-black font-extrabold' : 'hover:opacity-70'}`}
                title="Obsidian Black Theme"
              >
                BLACK
              </button>
            </div>

            <button 
              onClick={() => { setIsShopifyModalOpen(true); playSound(); }} 
              onMouseEnter={playSound}
              className={`group relative px-3 py-2 border ${t.borderBold} overflow-hidden ${colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black'} transition-all flex items-center gap-2`}
              title="Get Shopify Theme in Liquid code"
            >
              <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-white' : 'bg-black'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
              <span className={`relative z-10 text-[10px] font-black tracking-[0.15em] uppercase ${colorTheme === 'off-white' ? 'text-white group-hover:text-black' : 'text-black group-hover:text-white'} transition-colors duration-500 flex items-center gap-1.5`}>
                <Code2 className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">SHOPIFY THEME (.LIQUID)</span>
              </span>
            </button>

            <button 
              onClick={() => { setSoundEnabled(!soundEnabled); playSound(); }} 
              onMouseEnter={playSound}
              className={`group relative px-3 py-2 border ${t.borderBold} overflow-hidden bg-transparent transition-all`}
              title="Toggle Audio Feedback"
            >
              <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
              <span className={`relative z-10 text-[10px] font-bold tracking-[0.15em] uppercase ${t.text} ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500 flex items-center gap-1.5`}>
                {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">AUDIO</span>
              </span>
            </button>

            <button 
              onClick={() => { setCurrency(currency === 'EGP' ? 'USD' : 'EGP'); playSound(); }}
              onMouseEnter={playSound}
              className={`group relative px-3 py-2 border ${t.borderBold} overflow-hidden bg-transparent transition-all`}
            >
              <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
              <span className={`relative z-10 text-[10px] font-black tracking-[0.15em] uppercase ${t.text} ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>
                {currency}
              </span>
            </button>

            <button 
              onClick={() => { setIsSearchOpen(true); playSound(); }}
              onMouseEnter={playSound}
              className={`group relative p-2 border ${t.borderBold} overflow-hidden bg-transparent transition-all`}
            >
              <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
              <span className={`relative z-10 ${t.text} ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>
                <Search className="w-4 h-4" />
              </span>
            </button>

            <button 
              onClick={() => { setIsCartOpen(true); playSound(); }}
              onMouseEnter={playSound}
              className={`group relative px-4 py-2 border ${t.borderBold} overflow-hidden ${colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black'} transition-all`}
            >
              <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-white' : 'bg-black'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
              <span className={`relative z-10 text-[10px] font-black tracking-[0.2em] uppercase ${colorTheme === 'off-white' ? 'text-white group-hover:text-black' : 'text-black group-hover:text-white'} transition-colors duration-500 flex items-center gap-2`}>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>BAG</span>
                <span className={`${colorTheme === 'off-white' ? 'bg-white text-black group-hover:bg-black group-hover:text-white' : 'bg-black text-white group-hover:bg-white group-hover:text-black'} px-1.5 py-0.5 text-[9px] transition-colors`}>
                  {totalCartCount}
                </span>
              </span>
            </button>
          </div>

        </div>
      </header>

      {/* HERO SECTION */}
      <section id="manifesto" className={`px-6 sm:px-10 py-12 lg:py-16 flex flex-col justify-center border-b ${t.border} relative ${t.bg}`}>
        <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-8 flex flex-col justify-center">
            <h2 className={`text-[10px] font-bold tracking-[0.3em] uppercase mb-4 ${t.textDim}`}>
              MANIFESTO VOL. 01 • CAIRO URBAN CULTURAL ARCHIVE
            </h2>
            
            <h1 className={`text-5xl sm:text-7xl lg:text-8xl font-bold leading-[0.95] tracking-tighter uppercase mb-8 ${t.text}`}>
              REVIVING HISTORY<br/>
              ONE MORE TIME.
            </h1>

            <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center mb-8">
              <button 
                onClick={() => {
                  const el = document.getElementById('collection');
                  el?.scrollIntoView({ behavior: 'smooth' });
                  playSound();
                }}
                onMouseEnter={playSound}
                className={`group relative px-10 py-4 border ${t.borderBold} overflow-hidden bg-transparent transition-colors duration-500`}
              >
                <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                <span className={`relative z-10 text-[12px] font-black tracking-[0.2em] uppercase ${t.text} ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500 flex items-center gap-3`}>
                  <span>Explore the Drop</span>
                  <span>•</span>
                  <span dir="rtl" className="font-medium">اكتشف</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </span>
              </button>

              <div className={`text-[11px] leading-relaxed max-w-[260px] ${t.textMuted} uppercase tracking-wider font-medium`}>
                Urban cultural heritage reimagined for the modern silhouette. Designed & crafted in Cairo.
              </div>
            </div>

            <div className={`grid grid-cols-3 gap-6 pt-6 border-t ${t.border} max-w-lg text-[10px] font-bold uppercase tracking-widest`}>
              <div>
                <div className={`${t.textDim} mb-1`}>FABRIC WEIGHT</div>
                <div className="text-xs font-black">500 GSM COTTON</div>
              </div>
              <div>
                <div className={`${t.textDim} mb-1`}>ORIGIN</div>
                <div className="text-xs font-black">CAIRO, EGYPT</div>
              </div>
              <div>
                <div className={`${t.textDim} mb-1`}>CRAFT</div>
                <div className="text-xs font-black">HAND EMBROIDERED</div>
              </div>
            </div>
          </div>

          {/* HERO VISUAL CARD */}
          <div className="lg:col-span-4 relative">
            <div className={`group relative overflow-hidden ${t.cardBg} border ${t.border} cursor-pointer p-4`}>
              <div className={`relative aspect-[3/4] ${t.cardBgAlt} overflow-hidden mb-4 border ${t.border}`}>
                <img 
                  src="https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=80" 
                  alt="Nefertiti Beyoncé Hoodie" 
                  className="w-full h-full object-cover grayscale contrast-125 group-hover:scale-105 transition-transform duration-700"
                />
                <div className={`absolute top-3 left-3 ${t.badgeBg} px-2 py-1 text-[9px] font-bold tracking-widest uppercase`}>
                  DROP 004 HERO
                </div>
              </div>
              
              <div className="flex justify-between items-start">
                <div>
                  <span className={`text-[10px] font-bold tracking-widest ${t.textDim} uppercase`}>01 // OUTERWEAR</span>
                  <h3 className={`text-base font-bold uppercase tracking-tight leading-tight mt-1 ${t.text}`}>
                    The Nefertiti Beyoncé Hoodie
                  </h3>
                  <p className={`text-[11px] ${t.textMuted} font-medium mt-1`} dir="rtl">هودي نفرتيتي الفاخر 500GSM</p>
                </div>
                <span className={`text-xs font-black tracking-wider border ${t.borderBold} px-2 py-1`}>
                  {formatPrice(2800, 95)}
                </span>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* FEATURED CATEGORY STRIP */}
      <section className={`flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x ${t.border} border-b ${t.cardBg}`}>
        
        <div 
          onClick={() => { setActiveCategory('hoodies'); playSound(); }}
          className={`flex-1 group relative overflow-hidden ${t.cardBg} cursor-pointer min-h-[220px]`}
        >
          <div className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out`}></div>
          <div className={`relative z-10 p-6 h-full flex flex-col justify-between ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold tracking-widest">01</span>
              <span className={`text-[10px] ${t.textDim} group-hover:opacity-100 uppercase transition-opacity`}>Outerwear</span>
            </div>
            <div>
              <h3 className="text-lg font-bold uppercase tracking-tight leading-tight">
                The Nefertiti<br/>Beyoncé Hoodie
              </h3>
              <p className="text-[10px] mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 tracking-wider uppercase">
                Premium 500GSM Cotton Fleece
              </p>
            </div>
          </div>
        </div>

        <div 
          onClick={() => { setActiveCategory('cargos'); playSound(); }}
          className={`flex-1 group relative overflow-hidden ${t.cardBg} cursor-pointer min-h-[220px]`}
        >
          <div className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out`}></div>
          <div className={`relative z-10 p-6 h-full flex flex-col justify-between ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold tracking-widest">02</span>
              <span className={`text-[10px] ${t.textDim} group-hover:opacity-100 uppercase transition-opacity`}>Legwear</span>
            </div>
            <div>
              <h3 className="text-lg font-bold uppercase tracking-tight leading-tight">
                Multi-Way<br/>Utility Cargos
              </h3>
              <p className="text-[10px] mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 tracking-wider uppercase">
                Adjustable Tapered Canvas
              </p>
            </div>
          </div>
        </div>

        <div 
          onClick={() => { setActiveCategory('tees'); playSound(); }}
          className={`flex-1 group relative overflow-hidden ${t.cardBg} cursor-pointer min-h-[220px]`}
        >
          <div className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out`}></div>
          <div className={`relative z-10 p-6 h-full flex flex-col justify-between ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold tracking-widest">03</span>
              <span className={`text-[10px] ${t.textDim} group-hover:opacity-100 uppercase transition-opacity`}>Tops</span>
            </div>
            <div>
              <h3 className="text-lg font-bold uppercase tracking-tight leading-tight">
                Cairo Rosetta<br/>Heavy Tee
              </h3>
              <p className="text-[10px] mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 tracking-wider uppercase">
                320GSM Boxy Silhouette
              </p>
            </div>
          </div>
        </div>

        <div 
          onClick={() => { setActiveCategory('jackets'); playSound(); }}
          className={`flex-1 group relative overflow-hidden ${t.cardBg} cursor-pointer min-h-[220px]`}
        >
          <div className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out`}></div>
          <div className={`relative z-10 p-6 h-full flex flex-col justify-between ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold tracking-widest">04</span>
              <span className={`text-[10px] ${t.textDim} group-hover:opacity-100 uppercase transition-opacity`}>Craft</span>
            </div>
            <div>
              <h3 className="text-lg font-bold uppercase tracking-tight leading-tight">
                Kemet Varsity<br/>Monogram Jacket
              </h3>
              <p className="text-[10px] mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 tracking-wider uppercase">
                Melton Wool & Calfskin
              </p>
            </div>
          </div>
        </div>

      </section>

      {/* HERITAGE MANIFESTO SECTION */}
      <section id="heritage" className={`px-6 sm:px-10 py-16 border-b ${t.border} ${t.cardBg} relative`}>
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 flex flex-col gap-6">
            <span className={`text-[10px] font-bold tracking-[0.3em] uppercase ${t.textDim}`}>
              ARCHIVAL CULTURAL MANIFESTO
            </span>
            <h2 className={`text-3xl sm:text-5xl font-extrabold uppercase tracking-tight ${t.text} leading-tight`}>
              CULTURE IS NOT A TREND.<br/>
              IT IS OUR HERITAGE.
            </h2>
            <div className={`space-y-4 ${t.textMuted} font-normal leading-relaxed text-sm sm:text-base`}>
              <p>
                <strong className={`${t.text} font-bold`}>Asili (أصيلي)</strong> was born in Cairo to restore ancient Egyptian identity through minimal, brutalist streetwear silhouettes. Every archive piece is constructed with 500GSM Egyptian heavyweight cotton and hand-drawn calligraphic artwork.
              </p>
              <p className="font-medium text-base" dir="rtl">
                أصيلي ليست مجرد أزياء؛ بل هي إعادة إحياء للهوية الثقافية المصرية بجودة استثنائية وتصاميم معاصرة.
              </p>
            </div>

            <div className={`grid grid-cols-2 gap-4 pt-4 border-t ${t.border} text-xs font-bold uppercase tracking-widest`}>
              <div className={`p-4 border ${t.border} ${t.bg}`}>
                <div className={`${t.text} mb-1`}>100% NILE COTTON</div>
                <div className={`${t.textDim} text-[10px]`}>Milled in Delta factories</div>
              </div>
              <div className={`p-4 border ${t.border} ${t.bg}`}>
                <div className={`${t.text} mb-1`}>HAND-MADE IN CAIRO</div>
                <div className={`${t.textDim} text-[10px]`}>Artisanal local embroidery</div>
              </div>
            </div>
          </div>

          <div className={`lg:col-span-5 border ${t.borderBold} p-8 sm:p-12 text-center ${t.bg} flex flex-col items-center justify-center relative min-h-[300px]`}>
            <span className={`text-2xl font-black uppercase tracking-tighter ${t.text} mb-2`}>Asili.eg</span>
            <span className={`text-4xl font-bold tracking-widest ${t.text} mb-4`} dir="rtl">أصيلي</span>
            <div className={`w-12 h-0.5 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} my-2`}></div>
            <p className={`text-[11px] font-bold tracking-[0.25em] uppercase ${t.textDim} max-w-xs mt-2`}>
              REVIVING HISTORY ONE MORE TIME • CAIRO ARCHIVE
            </p>
          </div>

        </div>
      </section>

      {/* PRODUCTS CATALOG SECTION */}
      <section id="collection" className={`px-6 sm:px-10 py-16 border-b ${t.border} ${t.bg}`}>
        <div className="max-w-7xl mx-auto">
          
          <div className={`flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b ${t.border} pb-6`}>
            <div>
              <span className={`text-[10px] font-bold tracking-[0.3em] uppercase ${t.textDim} block mb-1`}>
                DROP 004 ARCHIVE CATALOG
              </span>
              <h2 className={`text-3xl sm:text-5xl font-black uppercase ${t.text} tracking-tight`}>
                COLLECTIONS
              </h2>
            </div>

            {/* FILTER BUTTONS */}
            <div className="flex flex-wrap items-center gap-2">
              {['all', 'hoodies', 'cargos', 'tees', 'jackets'].map(cat => (
                <button 
                  key={cat}
                  onClick={() => { setActiveCategory(cat); playSound(); }}
                  onMouseEnter={playSound}
                  className={`group relative px-4 py-2 border ${t.borderBold} overflow-hidden text-[11px] font-bold tracking-[0.2em] uppercase transition-all ${activeCategory === cat ? (colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black') : 'bg-transparent'}`}
                >
                  <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                  <span className={`relative z-10 transition-colors duration-500 ${activeCategory === cat ? (colorTheme === 'off-white' ? 'text-white' : 'text-black') : `${t.text} ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'}`}`}>
                    {cat === 'all' ? 'ALL DROPS [6]' : cat}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* PRODUCT GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map(p => (
              <div 
                key={p.id}
                className={`group relative border ${t.border} ${t.cardBg} p-6 flex flex-col justify-between transition-all duration-500 hover:${t.borderBold}`}
              >
                <div>
                  <div className={`relative aspect-[3/4] ${t.cardBgAlt} overflow-hidden mb-4 border ${t.border}`}>
                    <img 
                      src={p.image} 
                      alt={p.name} 
                      className="w-full h-full object-cover grayscale contrast-125 group-hover:scale-105 transition-transform duration-700"
                    />
                    
                    <div className={`absolute top-3 left-3 ${t.badgeBg} px-2 py-1 text-[9px] font-bold tracking-widest uppercase`}>
                      {p.badge}
                    </div>

                    <div className={`absolute top-3 right-3 ${t.badgeBorder} px-2 py-1 text-[9px] font-bold tracking-widest uppercase`}>
                      {p.gsm}
                    </div>

                    {/* Quick View Hover Actions */}
                    <div className={`absolute inset-x-0 bottom-0 p-3 ${t.cardBg}/95 border-t ${t.border} transform translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex items-center gap-2`}>
                      <button 
                        onClick={() => { setSelectedQuickView(p); playSound(); }}
                        onMouseEnter={playSound}
                        className={`flex-1 group relative px-3 py-2 border ${t.borderBold} overflow-hidden bg-transparent text-[10px] font-black tracking-widest uppercase ${t.text}`}
                      >
                        <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                        <span className={`relative z-10 ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500`}>QUICK VIEW</span>
                      </button>
                      <button 
                        onClick={() => handleAddToCart(p, 'M')}
                        onMouseEnter={playSound}
                        className={`flex-1 group relative px-3 py-2 border ${t.borderBold} overflow-hidden ${colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black'} text-[10px] font-black tracking-widest uppercase`}
                      >
                        <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-white' : 'bg-black'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                        <span className={`relative z-10 ${colorTheme === 'off-white' ? 'group-hover:text-black' : 'group-hover:text-white'} transition-colors duration-500`}>+ ADD BAG</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex justify-between items-start mb-2">
                    <h3 className={`text-base font-bold uppercase tracking-tight ${t.text}`}>{p.name}</h3>
                    <span className={`text-xs font-black ${t.text} whitespace-nowrap ml-2`}>
                      {formatPrice(p.priceEGP, p.priceUSD)}
                    </span>
                  </div>

                  <div className={`flex items-center justify-between text-xs ${t.textMuted} mb-4`}>
                    <span dir="rtl" className="font-medium">{p.arabicName}</span>
                    <span className={`text-[10px] font-bold uppercase ${t.textDim}`}>{p.gsm}</span>
                  </div>
                </div>

                {/* ADD TO BAG BUTTON */}
                <button 
                  onClick={() => handleAddToCart(p, 'L')}
                  onMouseEnter={playSound}
                  className={`w-full group relative px-6 py-3 border ${t.borderBold} overflow-hidden bg-transparent text-xs font-black tracking-[0.2em] uppercase ${t.text} transition-all`}
                >
                  <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-black' : 'bg-white'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                  <span className={`relative z-10 ${colorTheme === 'off-white' ? 'group-hover:text-white' : 'group-hover:text-black'} transition-colors duration-500 flex items-center justify-center gap-2`}>
                    <span>ADD TO BAG</span>
                    <span>•</span>
                    <span dir="rtl" className="font-medium">أضف للحقيبة</span>
                  </span>
                </button>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* FOOTER & NEWSLETTER */}
      <footer className="bg-black text-white px-6 sm:px-10 py-10 flex flex-col justify-between border-t border-black">
        <div className="max-w-7xl mx-auto w-full flex flex-col md:flex-row justify-between items-center gap-8">
          
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <span className="text-[10px] font-bold tracking-[0.2em] opacity-50 uppercase">Newsletter</span>
            <form 
              onSubmit={(e) => { e.preventDefault(); setSubscribed(true); playSound(); }}
              className="flex border-b border-white/30"
            >
              <input 
                type="email" 
                placeholder="EMAIL@ASILI.EG" 
                required
                className="bg-transparent border-none text-[10px] py-2 w-48 focus:ring-0 placeholder:text-white/30 uppercase tracking-widest text-white focus:outline-none"
              />
              <button 
                type="submit"
                onMouseEnter={playSound}
                className="group relative px-6 py-2 overflow-hidden transition-all bg-transparent border-none"
              >
                <span className="absolute inset-0 bg-white translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
                <span className="relative z-10 text-[9px] font-bold tracking-widest text-white group-hover:text-black transition-colors duration-500">
                  SUBSCRIBE
                </span>
              </button>
            </form>
          </div>

          <div className="flex flex-wrap items-center gap-8 text-[10px] font-bold tracking-widest opacity-60 uppercase">
            <span>©2026 ASILI (أصيلي)</span>
            <span>CAIRO, EG</span>
            <span>100% EGYPTIAN COTTON</span>
          </div>

        </div>

        {subscribed && (
          <div className="max-w-7xl mx-auto w-full mt-4 text-[10px] font-bold tracking-widest text-emerald-400 uppercase">
            ✓ YOU ARE NOW SUBSCRIBED TO THE ASILI ARCHIVE DROPS.
          </div>
        )}
      </footer>

      {/* CART DRAWER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-md ${t.bg} border-l ${t.borderBold} p-6 flex flex-col justify-between h-full ${t.text}`}>
            <div className={`flex items-center justify-between border-b ${t.border} pb-4`}>
              <div className="flex items-baseline gap-2">
                <h2 className="text-xl font-black uppercase tracking-wider">YOUR BAG</h2>
                <span dir="rtl" className="text-sm font-medium opacity-60">(حقيبة التسوق)</span>
              </div>
              <button onClick={() => setIsCartOpen(false)} className={`p-2 border ${t.borderBold} hover:bg-black hover:text-white transition-colors text-xs font-bold`}>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-6 space-y-4">
              {cart.length === 0 ? (
                <div className={`text-center py-12 ${t.textDim} text-xs font-bold uppercase tracking-widest space-y-2`}>
                  <p>YOUR BAG IS CURRENTLY EMPTY.</p>
                  <p dir="rtl" className="font-medium">حقيبة التسوق فارغة حالياً</p>
                </div>
              ) : (
                cart.map(item => (
                  <div key={`${item.id}-${item.size}`} className={`flex gap-4 p-3 border ${t.border} ${t.cardBg} items-center`}>
                    <img src={item.image} alt={item.name} className={`w-16 h-20 object-cover grayscale border ${t.border}`} />
                    <div className="flex-1 text-xs space-y-1">
                      <div className={`font-bold uppercase ${t.text}`}>{item.name}</div>
                      <div className={`opacity-60 text-[10px] uppercase font-bold ${t.textMuted}`}>SIZE: {item.size}</div>
                      <div className={`font-black ${t.text}`}>{formatPrice(item.priceEGP * item.qty, item.priceUSD * item.qty)}</div>
                      <div className="flex items-center gap-2 pt-1">
                        <button onClick={() => handleQtyChange(item.id, item.size, -1)} className={`p-1 border ${t.borderBold} ${t.text}`}><Minus className="w-3 h-3" /></button>
                        <span className="font-black">{item.qty}</span>
                        <button onClick={() => handleQtyChange(item.id, item.size, 1)} className={`p-1 border ${t.borderBold} ${t.text}`}><Plus className="w-3 h-3" /></button>
                      </div>
                    </div>
                    <button onClick={() => handleRemoveFromCart(item.id, item.size)} className={`${t.textDim} hover:${t.text}`}>
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className={`border-t ${t.border} pt-4 space-y-4`}>
              <div className={`flex justify-between ${t.text} text-sm font-black uppercase tracking-wider`}>
                <span>TOTAL</span>
                <span>{currency === 'EGP' ? `${totalCartPrice.toLocaleString()} EGP` : `$${totalCartPrice}`}</span>
              </div>
              <button 
                onClick={() => { alert('ASILI ARCHIVE CHECKOUT: Order Placed Successfully!'); setCart([]); setIsCartOpen(false); }}
                className={`w-full group relative px-6 py-4 border ${t.borderBold} overflow-hidden ${colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black'} text-xs font-black tracking-[0.2em] uppercase`}
              >
                <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-white' : 'bg-black'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                <span className={`relative z-10 ${colorTheme === 'off-white' ? 'group-hover:text-black' : 'group-hover:text-white'} transition-colors duration-500 flex items-center justify-center gap-2`}>
                  <span>PROCEED TO CHECKOUT</span>
                  <span>•</span>
                  <span dir="rtl" className="font-medium">إتمام الطلب</span>
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUICK VIEW MODAL */}
      {selectedQuickView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`${t.bg} border ${t.borderBold} max-w-2xl w-full p-6 sm:p-8 relative ${t.text} max-h-[90vh] overflow-y-auto`}>
            <button onClick={() => setSelectedQuickView(null)} className={`absolute top-4 right-4 p-2 border ${t.borderBold} hover:bg-black hover:text-white transition-colors`}>
              <X className="w-4 h-4" />
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mt-2">
              <div className={`relative aspect-[3/4] ${t.cardBgAlt} border ${t.border}`}>
                <img src={selectedQuickView.image} className="w-full h-full object-cover grayscale contrast-125" />
              </div>
              <div className="flex flex-col justify-between space-y-4">
                <div>
                  <span className={`text-[10px] font-bold tracking-widest ${t.textDim} uppercase block mb-1`}>
                    {selectedQuickView.badge}
                  </span>
                  <h2 className={`text-2xl font-black uppercase ${t.text} tracking-tight`}>{selectedQuickView.name}</h2>
                  <div dir="rtl" className={`text-sm font-medium ${t.textMuted}`}>{selectedQuickView.arabicName}</div>
                  <div className={`text-lg font-black ${t.text} mt-2`}>{formatPrice(selectedQuickView.priceEGP, selectedQuickView.priceUSD)}</div>
                  
                  <p className={`text-xs ${t.textMuted} leading-relaxed border-t ${t.border} pt-3 mt-3`}>
                    {selectedQuickView.description}
                  </p>

                  <div className={`space-y-1 border-t ${t.border} pt-3 text-xs mt-3 uppercase font-bold ${t.text}`}>
                    <div>FABRIC: {selectedQuickView.fabric}</div>
                    <div>WEIGHT: {selectedQuickView.gsm}</div>
                  </div>

                  <div className="space-y-2 pt-3">
                    <div className={`text-[10px] font-bold uppercase ${t.textDim}`}>SELECT SIZE:</div>
                    <div className="flex gap-2">
                      {['S', 'M', 'L', 'XL'].map(s => (
                        <button 
                          key={s}
                          onClick={() => setQuickViewSize(s)}
                          className={`px-3 py-1.5 border text-xs font-bold uppercase transition-colors ${quickViewSize === s ? (colorTheme === 'off-white' ? 'bg-black text-white border-black' : 'bg-white text-black border-white') : `${t.border} ${t.text} hover:${t.borderBold}`}`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => { handleAddToCart(selectedQuickView, quickViewSize); setSelectedQuickView(null); }}
                  className={`w-full group relative px-6 py-4 border ${t.borderBold} overflow-hidden ${colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black'} text-xs font-black tracking-[0.2em] uppercase`}
                >
                  <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-white' : 'bg-black'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
                  <span className={`relative z-10 ${colorTheme === 'off-white' ? 'group-hover:text-black' : 'group-hover:text-white'} transition-colors duration-500 flex items-center justify-center gap-2`}>
                    <span>ADD TO BAG NOW</span>
                    <span>•</span>
                    <span dir="rtl" className="font-medium">أضف للحقيبة</span>
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SEARCH MODAL */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/70 backdrop-blur-md">
          <div className={`max-w-xl w-full border ${t.borderBold} p-6 ${t.bg} ${t.text}`}>
            <div className={`flex items-center justify-between mb-4 border-b ${t.border} pb-3`}>
              <span className={`text-xs uppercase font-bold tracking-widest ${t.textDim}`}>SEARCH ARCHIVE // بحث</span>
              <button onClick={() => setIsSearchOpen(false)} className={`text-xs font-bold ${t.text}`}>✕ CLOSE</button>
            </div>
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="SEARCH HOODIES, CARGOS, TEES..." 
              className={`w-full ${t.cardBg} border ${t.borderBold} px-4 py-3 text-xs font-bold ${t.text} focus:outline-none mb-4 uppercase tracking-widest`}
              autoFocus
            />
            <div className="space-y-2 text-xs">
              {searchFilteredProducts.length > 0 ? (
                searchFilteredProducts.map(p => (
                  <div 
                    key={p.id} 
                    onClick={() => { setSelectedQuickView(p); setIsSearchOpen(false); }}
                    className={`p-3 border ${t.border} hover:${t.borderBold} ${t.cardBg} ${t.text} cursor-pointer flex justify-between items-center uppercase font-bold`}
                  >
                    <span>{p.name}</span>
                    <span>{formatPrice(p.priceEGP, p.priceUSD)}</span>
                  </div>
                ))
              ) : (
                <p className={`${t.textDim} uppercase font-bold text-[10px]`}>Try searching: "Nefertiti", "Cargo", "Varsity", "500GSM"</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* FLOATING SHOPIFY THEME EXPORTER BADGE */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-2 items-end">
        
        {/* THEME SELECTOR PILL */}
        <div className={`flex items-center border-2 ${t.borderBold} ${t.bg} p-1 text-[10px] font-black tracking-widest uppercase shadow-2xl`}>
          <span className={`px-2 text-[9px] ${t.textDim} hidden sm:inline`}>THEME:</span>
          <button 
            onClick={() => { setColorTheme('off-white'); playSound(); }}
            className={`px-2.5 py-1 transition-colors ${colorTheme === 'off-white' ? 'bg-black text-white' : `${t.text} hover:opacity-70`}`}
          >
            OFF-WHITE
          </button>
          <button 
            onClick={() => { setColorTheme('dark-gray'); playSound(); }}
            className={`px-2.5 py-1 transition-colors ${colorTheme === 'dark-gray' ? 'bg-white text-black font-bold' : `${t.text} hover:opacity-70`}`}
          >
            DARK GRAY
          </button>
          <button 
            onClick={() => { setColorTheme('black'); playSound(); }}
            className={`px-2.5 py-1 transition-colors ${colorTheme === 'black' ? 'bg-white text-black font-extrabold' : `${t.text} hover:opacity-70`}`}
          >
            BLACK
          </button>
        </div>

        <button
          onClick={() => { setIsShopifyModalOpen(true); playSound(); }}
          className={`group relative px-5 py-3 border-2 ${t.borderBold} ${colorTheme === 'off-white' ? 'bg-black text-white' : 'bg-white text-black'} shadow-2xl overflow-hidden transition-transform hover:scale-105`}
        >
          <span className={`absolute inset-0 ${colorTheme === 'off-white' ? 'bg-white' : 'bg-black'} translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out`}></span>
          <span className={`relative z-10 text-[11px] font-black tracking-[0.2em] uppercase ${colorTheme === 'off-white' ? 'text-white group-hover:text-black' : 'text-black group-hover:text-white'} transition-colors duration-500 flex items-center gap-2`}>
            <Download className="w-4 h-4" />
            <span>DOWNLOAD SHOPIFY THEME (.ZIP)</span>
          </span>
        </button>
      </div>

      {/* SHOPIFY THEME MODAL */}
      <ShopifyThemeModal 
        isOpen={isShopifyModalOpen} 
        onClose={() => setIsShopifyModalOpen(false)} 
      />

    </div>
  );
}
