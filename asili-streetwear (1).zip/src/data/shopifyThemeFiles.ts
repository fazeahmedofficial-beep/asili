export interface ShopifyThemeFile {
  path: string;
  category: 'layout' | 'sections' | 'snippets' | 'templates' | 'assets' | 'config';
  description: string;
  code: string;
}

export const SHOPIFY_THEME_FILES: ShopifyThemeFile[] = [
  {
    path: 'layout/theme.liquid',
    category: 'layout',
    description: 'Main Shopify theme layout wrapper with fonts, Tailwind CSS & Liquid hooks',
    code: `<!doctype html>
<html class="no-js" lang="{{ request.locale.iso_code }}">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="#F9F9F9">
    <link rel="canonical" href="{{ canonical_url }}">

    <title>
      {{ page_title }}
      {%- if current_tags %} &ndash; tagged "{{ current_tags | join: ', ' }}"{% endif -%}
      {%- if current_page != 1 %} &ndash; Page {{ current_page }}{% endif -%}
      {%- unless page_title contains shop.name %} &ndash; {{ shop.name }}{% endunless -%}
    </title>

    {% if page_description %}
      <meta name="description" content="{{ page_description | escape }}">
    {% endif %}

    <!-- Google Fonts & Tailwind CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;900&family=Noto+Kufi+Arabic:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    
    {{ 'asili-theme.css' | asset_url | stylesheet_tag }}
    {{ content_for_header }}
  </head>

  <body class="bg-[#F9F9F9] text-black font-sans min-h-screen flex flex-col relative select-none antialiased selection:bg-black selection:text-white">
    {% section 'announcement-bar' %}
    {% section 'header' %}

    <main id="MainContent" class="flex-1 focus-none" role="main" tabindex="-1">
      {{ content_for_layout }}
    </main>

    {% section 'footer' %}

    {% render 'cart-drawer' %}

    <script src="{{ 'asili-theme.js' | asset_url }}" defer="defer"></script>
  </body>
</html>`
  },
  {
    path: 'sections/announcement-bar.liquid',
    category: 'sections',
    description: 'Top scrolling marquee ticker announcement bar in Liquid',
    code: `{%- if section.settings.show_announcement -%}
  <div class="bg-black text-white text-[10px] font-bold py-2.5 border-b border-black overflow-hidden relative z-50 uppercase tracking-[0.25em]">
    <div class="animate-marquee whitespace-nowrap flex gap-12 items-center">
      <span>{{ section.settings.text_1 | default: "REVIVING HISTORY ONE MORE TIME" }}</span>
      <span>•</span>
      <span dir="rtl" class="font-medium">{{ section.settings.arabic_text | default: "أصيلي • CAIRO, EGYPT" }}</span>
      <span>•</span>
      <span>{{ section.settings.text_2 | default: "FREE EXPRESS SHIPPING ON ORDERS OVER 3000 EGP" }}</span>
      <span>•</span>
      <span dir="rtl">{{ section.settings.arabic_text_2 | default: "صُنع في مصر 100% EGYPTIAN COTTON" }}</span>
      <span>•</span>
      <span>{{ section.settings.text_3 | default: "ASILI.EG ARCHIVE DROP 004" }}</span>
    </div>
  </div>
{%- endif -%}

{% schema %}
{
  "name": "Announcement Bar",
  "settings": [
    {
      "type": "checkbox",
      "id": "show_announcement",
      "label": "Show Announcement Bar",
      "default": true
    },
    {
      "type": "text",
      "id": "text_1",
      "label": "Primary Text",
      "default": "REVIVING HISTORY ONE MORE TIME"
    },
    {
      "type": "text",
      "id": "arabic_text",
      "label": "Arabic Subtext",
      "default": "أصيلي • CAIRO, EGYPT"
    },
    {
      "type": "text",
      "id": "text_2",
      "label": "Secondary Promo",
      "default": "FREE EXPRESS SHIPPING ON ORDERS OVER 3000 EGP"
    }
  ]
}
{% endschema %}`
  },
  {
    path: 'sections/header.liquid',
    category: 'sections',
    description: 'Clean Minimalist Header navigation with cart badge & search drawer trigger',
    code: `<header class="sticky top-0 z-40 bg-[#F9F9F9]/95 backdrop-blur-md border-b border-black/10 transition-all">
  <div class="max-w-7xl mx-auto px-6 sm:px-10 h-20 flex items-center justify-between">
    
    <!-- BRAND LOGO -->
    <a href="{{ routes.root_url }}" class="flex items-baseline gap-4 group">
      <span class="text-2xl font-black tracking-tighter uppercase text-black group-hover:opacity-60 transition-opacity">
        {{ shop.name | default: "Asili.eg" }}
      </span>
      <span class="text-xl font-medium tracking-widest text-black/80" dir="rtl">
        {{ section.settings.arabic_logo | default: "أصيلي" }}
      </span>
    </a>

    <!-- DESKTOP NAVIGATION -->
    <nav class="hidden md:flex items-center gap-8 text-[11px] font-bold tracking-[0.2em] uppercase">
      {%- for link in linklists[section.settings.menu].links -%}
        <a href="{{ link.url }}" class="hover:opacity-50 transition-opacity {% if link.active %}opacity-100 font-extrabold{% else %}opacity-80{% endif %}">
          {{ link.title | escape }}
        </a>
      {%- else -%}
        <a href="#collection" class="hover:opacity-50 transition-opacity">Archive</a>
        <a href="#manifesto" class="hover:opacity-50 transition-opacity">Manifesto</a>
        <a href="#heritage" class="hover:opacity-50 transition-opacity">Heritage</a>
      {%- endfor -%}
    </nav>

    <!-- ACTIONS -->
    <div class="flex items-center gap-3">
      <!-- CURRENCY TOGGLE -->
      <button 
        type="button" 
        id="CurrencySelector"
        class="group relative px-3 py-2 border border-black overflow-hidden bg-transparent transition-all"
      >
        <span class="absolute inset-0 bg-black translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
        <span class="relative z-10 text-[10px] font-black tracking-[0.15em] uppercase text-black group-hover:text-white transition-colors duration-500">
          {{ cart.currency.iso_code | default: 'EGP' }}
        </span>
      </button>

      <!-- CART TRIGGER -->
      <a 
        href="{{ routes.cart_url }}" 
        id="CartTrigger" 
        class="group relative px-4 py-2 border border-black overflow-hidden bg-black transition-all flex items-center gap-2"
      >
        <span class="absolute inset-0 bg-white translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
        <span class="relative z-10 text-[10px] font-black tracking-[0.2em] uppercase text-white group-hover:text-black transition-colors duration-500 flex items-center gap-2">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
          <span>BAG</span>
          <span class="bg-white group-hover:bg-black text-black group-hover:text-white px-1.5 py-0.5 text-[9px] transition-colors">
            {{ cart.item_count }}
          </span>
        </span>
      </a>
    </div>

  </div>
</header>

{% schema %}
{
  "name": "Header",
  "settings": [
    {
      "type": "link_list",
      "id": "menu",
      "label": "Navigation Menu",
      "default": "main-menu"
    },
    {
      "type": "text",
      "id": "arabic_logo",
      "label": "Arabic Brand Name",
      "default": "أصيلي"
    }
  ]
}
{% endschema %}`
  },
  {
    path: 'sections/hero-manifesto.liquid',
    category: 'sections',
    description: 'Clean Minimalist Hero Manifesto section with Drop 004 highlight',
    code: `<section class="px-6 sm:px-10 py-12 lg:py-16 flex flex-col justify-center border-b border-black/10 relative bg-[#F9F9F9]">
  <div class="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
    
    <div class="lg:col-span-8 flex flex-col justify-center">
      <h2 class="text-[10px] font-bold tracking-[0.3em] uppercase mb-4 opacity-40">
        {{ section.settings.eyebrow | default: "MANIFESTO VOL. 01 • CAIRO URBAN CULTURAL ARCHIVE" }}
      </h2>
      
      <h1 class="text-5xl sm:text-7xl lg:text-8xl font-bold leading-[0.95] tracking-tighter uppercase mb-8 text-black">
        {{ section.settings.heading | default: "REVIVING HISTORY<br/>ONE MORE TIME." }}
      </h1>

      <div class="flex flex-col sm:flex-row gap-6 items-start sm:items-center mb-8">
        <a 
          href="{{ section.settings.button_link | default: "#collection" }}"
          class="group relative px-10 py-4 border border-black overflow-hidden bg-transparent transition-colors duration-500 inline-block"
        >
          <span class="absolute inset-0 bg-black translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
          <span class="relative z-10 text-[12px] font-black tracking-[0.2em] uppercase text-black group-hover:text-white transition-colors duration-500 flex items-center gap-3">
            <span>{{ section.settings.button_text | default: "Explore the Drop" }}</span>
            <span>•</span>
            <span dir="rtl" class="font-medium">{{ section.settings.button_arabic | default: "اكتشف" }}</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
          </span>
        </a>

        <div class="text-[11px] leading-relaxed max-w-[260px] opacity-70 uppercase tracking-wider font-medium">
          {{ section.settings.subtext | default: "Urban cultural heritage reimagined for the modern silhouette. Designed & crafted in Cairo." }}
        </div>
      </div>

      <div class="grid grid-cols-3 gap-6 pt-6 border-t border-black/10 max-w-lg text-[10px] font-bold uppercase tracking-widest">
        <div>
          <div class="opacity-40 mb-1">FABRIC WEIGHT</div>
          <div class="text-xs font-black">500 GSM COTTON</div>
        </div>
        <div>
          <div class="opacity-40 mb-1">ORIGIN</div>
          <div class="text-xs font-black">CAIRO, EGYPT</div>
        </div>
        <div>
          <div class="opacity-40 mb-1">CRAFT</div>
          <div class="text-xs font-black">HAND EMBROIDERED</div>
        </div>
      </div>
    </div>

    <!-- HERO VISUAL FEATURED ITEM -->
    <div class="lg:col-span-4 relative">
      <div class="group relative overflow-hidden bg-white border border-black/10 p-4">
        <div class="relative aspect-[3/4] bg-[#F0F0F0] overflow-hidden mb-4 border border-black/10">
          {%- if section.settings.featured_image -%}
            <img src="{{ section.settings.featured_image | image_url: width: 800 }}" alt="Hero Product" class="w-full h-full object-cover grayscale contrast-125 group-hover:scale-105 transition-transform duration-700">
          {%- else -%}
            <img src="https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=80" alt="Nefertiti Beyoncé Hoodie" class="w-full h-full object-cover grayscale contrast-125 group-hover:scale-105 transition-transform duration-700">
          {%- endif -%}
          <div class="absolute top-3 left-3 bg-black text-white px-2 py-1 text-[9px] font-bold tracking-widest uppercase">
            DROP 004 HERO
          </div>
        </div>
        
        <div class="flex justify-between items-start">
          <div>
            <span class="text-[10px] font-bold tracking-widest opacity-40 uppercase">01 // OUTERWEAR</span>
            <h3 class="text-base font-bold uppercase tracking-tight leading-tight mt-1">
              The Nefertiti Beyoncé Hoodie
            </h3>
            <p class="text-[11px] opacity-60 font-medium mt-1" dir="rtl">هودي نفرتيتي الفاخر 500GSM</p>
          </div>
          <span class="text-xs font-black tracking-wider border border-black px-2 py-1">
            2,800 EGP
          </span>
        </div>
      </div>
    </div>

  </div>
</section>

{% schema %}
{
  "name": "Hero Manifesto",
  "settings": [
    {
      "type": "text",
      "id": "eyebrow",
      "label": "Eyebrow Subtitle",
      "default": "MANIFESTO VOL. 01 • CAIRO URBAN CULTURAL ARCHIVE"
    },
    {
      "type": "richtext",
      "id": "heading",
      "label": "Main Headline",
      "default": "<p>REVIVING HISTORY<br/>ONE MORE TIME.</p>"
    },
    {
      "type": "image_picker",
      "id": "featured_image",
      "label": "Featured Drop Image"
    },
    {
      "type": "text",
      "id": "button_text",
      "label": "Button Label",
      "default": "Explore the Drop"
    },
    {
      "type": "text",
      "id": "button_arabic",
      "label": "Button Arabic Text",
      "default": "اكتشف"
    }
  ],
  "presets": [
    {
      "name": "Hero Manifesto"
    }
  ]
}
{% endschema %}`
  },
  {
    path: 'sections/featured-collections.liquid',
    category: 'sections',
    description: 'Minimalist 4-column hover slide category showcase',
    code: `<section class="flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-black/10 border-b border-black/10 bg-white">
  {% for collection in collections limit: 4 %}
    <a href="{{ collection.url }}" class="flex-1 group relative overflow-hidden bg-white cursor-pointer min-h-[220px]">
      <div class="absolute inset-0 bg-black translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out"></div>
      <div class="relative z-10 p-6 h-full flex flex-col justify-between group-hover:text-white transition-colors duration-500">
        <div class="flex justify-between items-start">
          <span class="text-[10px] font-bold tracking-widest">0{{ forloop.index }}</span>
          <span class="text-[10px] opacity-40 group-hover:opacity-100 uppercase transition-opacity">
            {{ collection.title }}
          </span>
        </div>
        <div>
          <h3 class="text-lg font-bold uppercase tracking-tight leading-tight">
            {{ collection.title }}
          </h3>
          <p class="text-[10px] mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 tracking-wider uppercase">
            {{ collection.products_count }} Items • View Archive
          </p>
        </div>
      </div>
    </a>
  {% else %}
    <div class="flex-1 p-6 font-mono text-xs uppercase opacity-50">No collections configured</div>
  {% endfor %}
</section>

{% schema %}
{
  "name": "Featured Strip",
  "settings": [],
  "presets": [
    {
      "name": "Featured Strip"
    }
  ]
}
{% endschema %}`
  },
  {
    path: 'sections/product-grid.liquid',
    category: 'sections',
    description: 'Product catalog grid with clean filter pills and dynamic product cards',
    code: `<section id="collection" class="px-6 sm:px-10 py-16 border-b border-black/10 bg-[#F9F9F9]">
  <div class="max-w-7xl mx-auto">
    
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-black/10 pb-6">
      <div>
        <span class="text-[10px] font-bold tracking-[0.3em] uppercase opacity-40 block mb-1">
          DROP 004 ARCHIVE CATALOG
        </span>
        <h2 class="text-3xl sm:text-5xl font-black uppercase text-black tracking-tight">
          {{ collection.title | default: "COLLECTIONS" }}
        </h2>
      </div>

      <div class="flex flex-wrap items-center gap-2">
        <button class="group relative px-4 py-2 border border-black bg-black text-white text-[11px] font-bold tracking-[0.2em] uppercase">
          ALL DROPS
        </button>
      </div>
    </div>

    <!-- PRODUCT GRID -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      {%- for product in collection.products -%}
        {% render 'product-card', product: product %}
      {%- else -%}
        {% comment %} Fallback hardcoded demonstration cards if shop empty {% endcomment %}
        <p class="text-xs font-mono uppercase opacity-60 col-span-full">No products found in this collection.</p>
      {%- endfor -%}
    </div>

  </div>
</section>

{% schema %}
{
  "name": "Product Grid Catalog",
  "settings": [],
  "presets": [
    {
      "name": "Product Grid Catalog"
    }
  ]
}
{% endschema %}`
  },
  {
    path: 'snippets/product-card.liquid',
    category: 'snippets',
    description: 'Reusable Liquid product card component with slide-up hover buttons',
    code: `<div class="group relative border border-black/10 bg-white p-6 flex flex-col justify-between transition-all duration-500 hover:border-black">
  <div>
    <a href="{{ product.url }}" class="block relative aspect-[3/4] bg-[#F0F0F0] overflow-hidden mb-4 border border-black/10">
      {%- if product.featured_image -%}
        <img src="{{ product.featured_image | image_url: width: 600 }}" alt="{{ product.title | escape }}" class="w-full h-full object-cover grayscale contrast-125 group-hover:scale-105 transition-transform duration-700">
      {%- else -%}
        <div class="w-full h-full flex items-center justify-center text-xs font-mono uppercase opacity-30">NO IMAGE</div>
      {%- endif -%}

      <div class="absolute top-3 left-3 bg-black text-white px-2 py-1 text-[9px] font-bold tracking-widest uppercase">
        ARCHIVE
      </div>

      <div class="absolute top-3 right-3 bg-white border border-black text-black px-2 py-1 text-[9px] font-bold tracking-widest uppercase">
        500 GSM
      </div>
    </a>

    <div class="flex justify-between items-start mb-2">
      <h3 class="text-base font-bold uppercase tracking-tight text-black">
        <a href="{{ product.url }}">{{ product.title }}</a>
      </h3>
      <span class="text-xs font-black text-black whitespace-nowrap ml-2">
        {{ product.price | money }}
      </span>
    </div>

    <div class="flex items-center justify-between text-xs text-black/60 mb-4">
      <span dir="rtl" class="font-medium">{{ product.metafields.asili.arabic_name | default: "قطعة من الأرشيف" }}</span>
      <span class="text-[10px] font-bold uppercase opacity-60">CAIRO, EG</span>
    </div>
  </div>

  <form method="post" action="/cart/add">
    <input type="hidden" name="id" value="{{ product.variants.first.id }}" />
    <button 
      type="submit" 
      class="w-full group relative px-6 py-3 border border-black overflow-hidden bg-transparent text-xs font-black tracking-[0.2em] uppercase text-black transition-all"
    >
      <span class="absolute inset-0 bg-black translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
      <span class="relative z-10 group-hover:text-white transition-colors duration-500 flex items-center justify-center gap-2">
        <span>ADD TO BAG</span>
        <span>•</span>
        <span dir="rtl" class="font-medium">أضف للحقيبة</span>
      </span>
    </button>
  </form>
</div>`
  },
  {
    path: 'sections/footer.liquid',
    category: 'sections',
    description: 'Shopify footer section with newsletter signup & Arabic calligraphy watermark',
    code: `<footer class="bg-black text-white border-t border-black/10 pt-16 pb-12 relative overflow-hidden">
  <div class="font-sans text-[14rem] sm:text-[20rem] text-white/5 font-bold select-none absolute bottom-0 right-0 translate-x-1/4 translate-y-1/4 pointer-events-none" dir="rtl">
    أصيلي
  </div>

  <div class="max-w-7xl mx-auto px-6 sm:px-10 relative z-10">
    <div class="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-white/20">
      
      <div class="md:col-span-5 flex flex-col gap-6">
        <a href="{{ routes.root_url }}" class="inline-block">
          <span class="text-3xl font-black uppercase tracking-tighter text-white">ASILI.EG</span>
          <div class="text-xs font-bold tracking-[0.25em] text-white/60 uppercase mt-1">
            asili.eg • <span dir="rtl" class="font-medium text-white">أصيلي</span>
          </div>
        </a>
        <p class="text-xs text-white/70 max-w-sm leading-relaxed font-normal">
          REVIVING HISTORY ONE MORE TIME.<br/>
          High-contrast cultural streetwear designed in Cairo, Egypt. Heavyweight fabrics, artisanal embroidery, and authentic Arabic calligraphy.
        </p>
        <div class="text-xs text-white/50 font-medium" dir="rtl">
          القاهرة • مصر | جميع الحقوق محفوظة © {{ 'now' | date: "%Y" }}
        </div>
      </div>

      <div class="md:col-span-7 flex flex-col justify-between gap-6">
        <div>
          <span class="text-[10px] font-bold tracking-[0.3em] text-white/50 uppercase mb-2 block">
            // VIP ARCHIVE ACCESS
          </span>
          <h3 class="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight">
            JOIN THE ASILI MOVEMENT
          </h3>
        </div>

        {% form 'customer', class: 'flex flex-col sm:flex-row gap-3' %}
          <input type="hidden" name="contact[tags]" value="newsletter">
          <input 
            type="email" 
            name="contact[email]"
            placeholder="ENTER YOUR EMAIL..." 
            required 
            class="flex-1 bg-transparent border border-white/40 px-4 py-3.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-white transition-colors uppercase tracking-widest"
          />
          
          <button 
            type="submit" 
            class="group relative border border-white bg-white px-8 py-3.5 text-black text-xs font-black tracking-widest uppercase transition-all overflow-hidden"
          >
            <span class="absolute inset-0 bg-black translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
            <span class="relative z-10 text-black group-hover:text-white transition-colors duration-500 flex items-center justify-center gap-2">
              <span>SUBSCRIBE</span>
              <span dir="rtl">اشترك</span>
            </span>
          </button>
        {% endform %}
      </div>

    </div>

    <div class="pt-8 flex flex-col sm:flex-row items-center justify-between gap-6 text-[10px] font-bold tracking-widest text-white/50 uppercase">
      <div class="flex flex-wrap items-center gap-6">
        <span>SHIPPING & RETURNS</span>
        <span>SIZE GUIDE (500 GSM)</span>
        <span>CARE INSTRUCTIONS</span>
        <span>INSTAGRAM @ASILI.EG</span>
      </div>
      <div>
        © {{ 'now' | date: "%Y" }} ASILI (أصيلي). ALL RIGHTS RESERVED.
      </div>
    </div>
  </div>
</footer>

{% schema %}
{
  "name": "Footer",
  "settings": []
}
{% endschema %}`
  },
  {
    path: 'assets/asili-theme.js',
    category: 'assets',
    description: 'Interactive theme controller for color scheme toggling (Off-White, Dark Gray, Black) and cart drawer',
    code: `/* Asili.eg Theme Controller */
document.addEventListener('DOMContentLoaded', () => {
  // Theme Color Scheme Handler (Off-White, Dark Gray, Obsidian Black)
  const savedTheme = localStorage.getItem('asili_color_theme') || 'off-white';
  setAsiliTheme(savedTheme);

  const themeSelectors = document.querySelectorAll('[data-asili-theme]');
  themeSelectors.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const theme = e.currentTarget.getAttribute('data-asili-theme');
      setAsiliTheme(theme);
    });
  });

  function setAsiliTheme(mode) {
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem('asili_color_theme', mode);
    
    // Update active UI badges
    themeSelectors.forEach(btn => {
      if (btn.getAttribute('data-asili-theme') === mode) {
        btn.classList.add('border-black', 'bg-black', 'text-white');
      } else {
        btn.classList.remove('border-black', 'bg-black', 'text-white');
      }
    });
  }
});`
  },
  {
    path: 'assets/asili-theme.css',
    category: 'assets',
    description: 'Custom styling & CSS variables for Off-White, Dark Gray, and Obsidian Black color modes',
    code: `/* Asili.eg Shopify Theme Stylesheet */

:root {
  --asili-bg: #F9F9F9;
  --asili-text: #000000;
  --asili-card-bg: #FFFFFF;
  --asili-border: rgba(0, 0, 0, 0.1);
  --asili-border-bold: #000000;
}

[data-theme="dark-gray"] {
  --asili-bg: #1A1A1A;
  --asili-text: #E5E5E5;
  --asili-card-bg: #242424;
  --asili-border: rgba(255, 255, 255, 0.15);
  --asili-border-bold: #FFFFFF;
}

[data-theme="black"] {
  --asili-bg: #0B0B0B;
  --asili-text: #FFFFFF;
  --asili-card-bg: #141414;
  --asili-border: rgba(255, 255, 255, 0.2);
  --asili-border-bold: #FFFFFF;
}

@keyframes marquee {
  0% { transform: translateX(0%); }
  100% { transform: translateX(-50%); }
}

.animate-marquee {
  display: inline-flex;
  animation: marquee 25s linear infinite;
}

body {
  background-color: var(--asili-bg);
  color: var(--asili-text);
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
  margin: 0;
  padding: 0;
  transition: background-color 0.3s ease, color 0.3s ease;
}

::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}
::-webkit-scrollbar-track {
  background: var(--asili-bg);
}
::-webkit-scrollbar-thumb {
  background: var(--asili-text);
}`
  },
  {
    path: 'config/settings_schema.json',
    category: 'config',
    description: 'Shopify theme configuration schema for customization in Shopify Theme Editor',
    code: `[
  {
    "name": "theme_info",
    "theme_name": "Asili Clean Minimalism",
    "theme_author": "Asili Design Team",
    "theme_version": "1.1.0",
    "theme_documentation_url": "https://asili.eg",
    "theme_support_url": "https://asili.eg/support"
  },
  {
    "name": "Color Modes & Presets",
    "settings": [
      {
        "type": "select",
        "id": "default_color_mode",
        "label": "Default Color Mode",
        "default": "off-white",
        "options": [
          { "value": "off-white", "label": "Off-White (#F9F9F9 Clean Minimalism)" },
          { "value": "dark-gray", "label": "Dark Gray (#1A1A1A Subtle Dark)" },
          { "value": "black", "label": "Obsidian Black (#0B0B0B Brutalist Dark)" }
        ]
      },
      {
        "type": "checkbox",
        "id": "allow_user_theme_switch",
        "label": "Allow customers to toggle between White, Dark Gray, and Black",
        "default": true
      }
    ]
  },
  {
    "name": "Custom Color Palette",
    "settings": [
      {
        "type": "color",
        "id": "color_bg_custom",
        "label": "Custom Page Background Color",
        "default": "#F9F9F9"
      },
      {
        "type": "color",
        "id": "color_card_custom",
        "label": "Custom Card Background",
        "default": "#FFFFFF"
      },
      {
        "type": "color",
        "id": "color_text_custom",
        "label": "Custom Primary Text Color",
        "default": "#000000"
      },
      {
        "type": "color",
        "id": "color_accent_custom",
        "label": "Custom Border & Accent Color",
        "default": "#000000"
      }
    ]
  },
  {
    "name": "Typography & Heritage",
    "settings": [
      {
        "type": "checkbox",
        "id": "show_arabic_typography",
        "label": "Enable Arabic Calligraphy & Subtitles",
        "default": true
      },
      {
        "type": "text",
        "id": "brand_arabic_subtitle",
        "label": "Arabic Brand Subtitle",
        "default": "أصيلي"
      }
    ]
  }
]`
  },
  {
    path: 'templates/index.json',
    category: 'templates',
    description: 'Shopify Online Store 2.0 homepage template composition JSON',
    code: `{
  "sections": {
    "announcement": {
      "type": "announcement-bar"
    },
    "hero": {
      "type": "hero-manifesto"
    },
    "featured_strip": {
      "type": "featured-collections"
    },
    "product_grid": {
      "type": "product-grid"
    }
  },
  "order": [
    "announcement",
    "hero",
    "featured_strip",
    "product_grid"
  ]
}`
  }
];
